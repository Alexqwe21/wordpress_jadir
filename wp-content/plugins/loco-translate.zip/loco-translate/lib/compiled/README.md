# Compiled libraries

These files are built from the Loco core. Do not edit!

They've been converted down for PHP 7.2.24 compatibility in WordPress.
