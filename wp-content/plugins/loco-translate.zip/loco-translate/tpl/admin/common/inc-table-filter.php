
    <form class="loco-filter" action="#">
        <fieldset class="loco-clearable">
            <input type="text" name="q" value="" autocomplete="off" placeholder="<?php 
            // translators: text field placeholder
            esc_html_e('Filter...','loco-translate')?>" size="20" />
        </fieldset>
    </form>
